<h1 align='center'> Tensorflow Tutorial </h1>

<p> Hey Everyone, This repo is just me re-learning and practicing some of the very basics of tensorflow. Anyone who is starting out on tensorflow learning  process can just replicate the code and follow along with my process </p>
<br>

<hr>

<p> All the notebook corresponds to learning something new in terms of code. I will possibly rework the notebooks to make it more detail oriented.

<ol>
    <li> <a href='tensorflow_learning_1.ipynb'> Basics of tensorflow </a></li>
        <p> This notebook is for very basics as to understand how to train simple model with mnist dataset. </p>
    <li><a href='tensorflow_image_classification.ipynb'> Image Classification </a></li>
</ol> 
